To Run App:
	1) Set working directory to Project2
	2) Run top two lines of main.R 