# NYC Data Science Academy - Project 2 - Shiny Application

Analysis of mass shootings in America. Visualizations built into a shiny application using leaflet and multiple plots.

# Blog Post:
Coming Soon