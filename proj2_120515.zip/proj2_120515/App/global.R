# Global - variable loading


load('data/Project2_UD.Rdata')


